import{p as a}from"./BtMtoYAL.js";a();
